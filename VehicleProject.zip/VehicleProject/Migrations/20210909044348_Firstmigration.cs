﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace VehicleProject.Migrations
{
    public partial class Firstmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Vehicle",
                columns: table => new
                {
                    VehicleNo = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Branch = table.Column<string>(type: "nvarchar(5)", maxLength: 5, nullable: false),
                    VehicleType = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Ins_ExpiryDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastServicedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DueDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicle", x => x.VehicleNo);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Vehicle");
        }
    }
}
