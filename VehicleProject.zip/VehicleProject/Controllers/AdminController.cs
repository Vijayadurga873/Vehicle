﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleProject.Models;

namespace VehicleProject.Controllers
{
    public class AdminController : Controller
    {
        private readonly VehicleDbContext _context;

        public AdminController(VehicleDbContext context)
        {
            _context = context;
        }
        public IActionResult login()
        {

            return View();
        }
        [HttpPost]
        public ActionResult login(AdminLogin user)
        {
            var v = _context.Admin.Where(a => a.Username == user.Username).FirstOrDefault();
            if (v != null)
            {
                int a = String.Compare(user.Password, v.Password);
                if (a == 0)
                {
                    //Session["username"] = v.Username;
                    return RedirectToAction("main", "Admin", new { username = v.Username });
                }
                else
                {
                    ViewBag.msg = "Password is incorrect";
                    return View();
                }
            }
            else
            {
                ViewBag.Msg = "Username doesn't exists";
                return View();
            }

        }
        public IActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MemberId,FirstName,LastName,Age,Gender,ContactNumber,EmailId,Username,Password,ConfirmPassword,Branch")] Admin user)
        {
            if (ModelState.IsValid)
            {
                _context.Add(user);
                await _context.SaveChangesAsync();
                return View();
            }
            return View();
        }

        public ActionResult main(string username)
        {
            ViewBag.username = username;
            return View();
        }
        public ActionResult Index()
        {
            return View(_context.User.Where(a=>a.Status=="Not Approved").ToList());
        }
    }
}
