﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleProject.Models;

namespace VehicleProject.Controllers
{
    public class VehicleController : Controller
    {
        VehicleDbContext context;
        public VehicleController(VehicleDbContext vContext)
        {
            context = vContext;
        }
        // GET: VehicleController
        public ActionResult Index()
        {
            return View(context.Vehicle.ToList());
        }
        public ActionResult Details(int id)
        {
            Vehicle vehicle = context.Vehicle.Find(id);
            return View(vehicle);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Vehicle vehicle)
        {
            context.Vehicle.Add(vehicle);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Update(int id)
        {
            Vehicle vehicle = context.Vehicle.Find(id);
            return View(vehicle);
        }
        [HttpPost]
        public ActionResult Update(Vehicle vehicle)
        {
            context.Update(vehicle);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Delete(int? id)
        {
            if(id==null)
                return BadRequest();
            Vehicle vehicle = context.Vehicle.Find(id);
            if (vehicle == null)
                return NotFound();
            return View(vehicle);
        }
        [HttpPost]
        public ActionResult Delete(Vehicle vehicle)
        {
            context.Remove(vehicle);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult UserIndex()
        {
            return View(context.Vehicle.ToList());
        }
    }
}
