﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleProject.Models;

namespace VehicleProject.Controllers
{
    public class VehicleController : Controller
    {
        VehicleDbContext context;
        public VehicleController(VehicleDbContext vContext)
        {
            context = vContext;
        }
        // GET: VehicleController
        public ActionResult Index()
        {
            return View(context.Vehicle.ToList());
        }
        public ActionResult Details(int id)
        {
            Vehicle vehicle = context.Vehicle.Find(id);
            return View(vehicle);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Vehicle vehicle)
        {
            context.Vehicle.Add(vehicle);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Update(int id)
        {
            Vehicle vehicle = context.Vehicle.Find(id);
            return View(vehicle);
        }
        [HttpPost]
        public ActionResult Update(Vehicle vehicle)
        {
            context.Update(vehicle);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Delete(int? id)
        {
            if (id == null)
                return BadRequest();
            Vehicle vehicle = context.Vehicle.Find(id);
            if (vehicle == null)
                return NotFound();
            return View(vehicle);
        }
        [HttpPost]
        public ActionResult Delete(Vehicle vehicle)
        {
            context.Remove(vehicle);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult UserIndex()
        {
            return View(context.Vehicle.ToList());
        }
        public ActionResult Reserved(int id)
        {
            Vehicle vehicle = context.Vehicle.Find(id);
            System.Random random = new System.Random();
            int price= 2 * random.Next(1000, 2000);
            HttpContext.Session.SetInt32("Price", price);
            ViewBag.price = price;
            return View(vehicle);
        }
        [HttpGet]
        public ActionResult Payment()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Payment(BalanceCheck bal)
        {
            int? value = HttpContext.Session.GetInt32("Price");
            //Payment customer = context.Payment.Find(bal.AccountNo);
            Payment customer = context.Payment.Where(a => a.AccountNo == bal.AccountNo).FirstOrDefault();
            if(customer!=null)
            {
                int compare = string.Compare(bal.Name, customer.Name);
                if(bal.CVV==customer.CVV && compare==0)
                {
                    if(customer.Balance>=value)
                    {
                        ViewBag.Msg = "Payment Sucessful!!";
                        return View();
                    }
                    else
                    {
                        ViewBag.Msg = "Insufficient Balance";
                        return View(bal);
                    }
                }
                else
                {
                    ViewBag.Msg = "Invalid Name or CVV";
                    return View(bal);
                }
            }
            else
            {
                ViewBag.Msg = "Account doesn't exists";
                return View(User);
            }
        }
    }
}
