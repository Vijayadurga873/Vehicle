﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleProject.Models
{
    [Table("Payment")]
    public class Payment
    {
        [Key]
        public int Id { get; set; }
        public long AccountNo { get; set; }
        public string Name { get; set; }

        public int CVV { get; set; }
        public int Balance { get; set; }
    }
}
