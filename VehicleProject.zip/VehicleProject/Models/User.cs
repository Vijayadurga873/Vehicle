﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleProject.Models
{
    [Table("User")]
    public class User
    {
        [Key]
        public int MemberId { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [StringLength(50)]
        [Display(Name ="Firstname")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [StringLength(50)]
        [Display(Name = "Lastname")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [Display(Name = "Age")]
        public int Age { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [Display(Name = "Contact Number")]
        [RegularExpression(@"^[6-9]{1}[0-9]{9}$", ErrorMessage = "Please enter valid mobile number")]
        public long ContactNumber { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [StringLength(50)]
        [Display(Name = "Email ID")]
        [DataType(DataType.EmailAddress)]
        public string EmailId { get; set; }
        public string Username { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [StringLength(15)]
        [Display(Name = "Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [StringLength(15)]
        [Display(Name = "Confirm Password")]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
        [StringLength(5)]
        [Display(Name = "Branch")]
        public string Branch { get; set; }
        [Required(ErrorMessage = "Please update the highlighted mandatory fields")]
       
        [Display(Name = "Status")]
        public string Status { get; set; }

    }
}
