﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleProject.Models
{
    public class Vehicle
    {
        [Key]
        public int VehicleId { get; set; }
        [Required]
        [StringLength(10)]
        public string  VehicleNo { get; set; }
        [Required]
        [StringLength(5)]
        public string Branch { get; set; }
        [Required]
        [StringLength(15)]
        public string VehicleType { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime Ins_ExpiryDate { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime LastServicedDate { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }

    }
}
