﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleProject.Models
{
    public class BalanceCheck
    {
        [Required(ErrorMessage = "Please enter the valid Account Number")]
        [Display(Name = "Account Number")]
        public long AccountNo { get; set; }
        [Required(ErrorMessage = "Please enter valid name")]
        [Display(Name = "Account Holder Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter valid CVV")]
        [Display(Name = "CVV")]
        public int CVV { get; set; }

    }
}
